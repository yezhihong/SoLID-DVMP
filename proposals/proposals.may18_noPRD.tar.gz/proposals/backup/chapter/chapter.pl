latex chapter.tex
dvips -o -tletter chapter.dvi
ps2pdf chapter.ps
acroread chapter.pdf &

